#include "WorldEngine.h"
#include "WorldPresets.h"
#include <iostream>
#include <stdexcept>
void check(bool x,const char*m){if(!x)throw std::runtime_error(m);}
float render(world::Engine&e,int frames){float peak=0;while(frames--){float l,r;e.sample(l,r);check(std::isfinite(l)&&std::isfinite(r),"Non-finite audio");check(std::abs(l)<=1.001f&&std::abs(r)<=1.001f,"Unprotected output");peak=std::max(peak,std::max(std::abs(l),std::abs(r)));}return peak;}
int main(){try{
 for(auto&patch:world::patches){for(size_t i=0;i<patch.values.size();i++)check(patch.values[i]>=world::specs[i].lo&&patch.values[i]<=world::specs[i].hi,"Preset out of range");world::Engine e;e.prepare(48000);e.parameters(patch.values);e.noteOn(60,.9f);check(render(e,16000)>.000001f,"Silent world preset");e.noteOff(60);render(e,8000);e.reset();check(render(e,64)==0,"Panic did not clear output");}
 for(double sr:{44100.,48000.,96000.}){world::Engine a,b;a.prepare(sr);b.prepare(sr);auto p=world::patches[20].values;p[world::Release]=20;a.parameters(p);b.parameters(p);a.noteOn(60,.8f);check(render(a,2000)>0,"Voice silent");check(render(b,2000)==0,"Pad engines leaked sound");a.controller(64,127);a.noteOff(60);render(a,2000);check(a.activeVoices()>0,"Sustain pedal failed");a.controller(64,0);render(a,(int)sr);check(a.activeVoices()==0,"Stuck sustain note");for(int n=40;n<60;n++)a.noteOn(n,.8f);check(a.activeVoices()==8,"Voice stealing failed");a.reset();}
 auto sample=std::make_shared<world::SampleData>();sample->rate=48000;sample->left.resize(4800);sample->right.resize(4800);for(size_t i=0;i<4800;i++){sample->left[i]=.3f*std::sin(2*davoe::pi*440*i/48000);sample->right[i]=.2f*std::sin(2*davoe::pi*660*i/48000);}
 world::Engine e;e.prepare(48000);auto p=world::defaults();p[world::Source]=1;p[world::Sustain]=1;p[world::Release]=20;e.parameters(p);e.setSample(sample);e.noteOn(60,.9f);check(render(e,4000)>.001f,"Sample playback silent");render(e,2000);check(e.activeVoices()==0,"One-shot sample did not end");p[world::SampleLoop]=1;e.parameters(p);e.noteOn(60,.9f);render(e,16000);check(e.activeVoices()==1,"Loop did not hold");e.noteOff(60);render(e,48000);check(e.activeVoices()==0,"Loop release failed");e.reset();check(render(e,64)==0,"Sample reset failed");
 std::cout<<"PASS: 160 preset ranges/audio, six models, pad isolation, sustain, polyphony, stereo samples, looping and reset\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
