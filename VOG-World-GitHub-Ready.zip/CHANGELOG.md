# 1.0.0
Initial VOG World: 160 synthesized world-instrument patches, sixteen independent synth/sample pads, per-pad ADSR/rotary filter/FX, autoplay rhythms, keyboard, 30-second recording, WAV import/export and embedded-audio pad/kit saving.
